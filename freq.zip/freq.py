# ---------------------
# Name: Zi Xue Lim
# ID:1573849
# CMPT274, Fall 2019
# Excercise Unfair Dice
# ---------------------
# You must determine how to structure your solution.
# Create your functions here and call them from under
# if __name__ == "__main__"!
import sys
def fileToWords(file):  # build a list based on number of lines
	lengthFile = len(file)
	wordList= []
	for i in range (lengthFile):
		line = str(file[i])
		lineList = line.split()
		for x in range (len(lineList)):
			wordList.append(lineList[x])
	return wordList

def sortWords(wordList):  # sort words in correct order and only 1 of each word in the list
	sortedWords = []
	for p in range(len(wordList)):
		if wordList[p] not in (sortedWords):
			sortedWords.append(wordList[p])
	sortedWords = sorted(sortedWords)
	return sortedWords

def countedWords(sortedWords,wordList):  # compare each word to a word in sortedWord list
	dictWords = {}
	count = 0
	for m in range (len(sortedWords)):
		for b in range (len(wordList)):
			if sortedWords[m] == wordList[b]:
				count = count + 1
		dictWords[sortedWords[m]] = count
		count = 0
	return dictWords

def ratioFun (wordList,sortedWords,countWords):
	ratioWords={}
	for u in range(len(sortedWords)):
		ratio = countWords[sortedWords[u]]/lenWords
		ratioWords[sortedWords[u]] = round(ratio,3)
	return ratioWords
def outFunc (ratioWords,countWords,sortedWords):
	for a in range(len(sortedWords)):  #outputs the table with ratios calculated to 3dp
		word = sortedWords[a]
		print(word + " " + str(countWords[word]) + " " + str(ratioWords[word]))

if __name__ == "__main__":
	lenInput = len(sys.argv)
	if lenInput < 2:  # if statment to check if less than 2 which means the user only import python3 freq.py
		print("There are too few commands line arguments. It should look something like this: \npython3 freq.py sample0")
	elif lenInput > 2:  # if statment to check if greater than 2.
		print("There are too many command-line arguments. It should look something like this: \npython3 freq.py sample1")
	else:
		fileName = sys.argv[1]  # read only the file user wants to read
		file = open(fileName, "r").read().split('\n')  #splits the file into list based on the lines
		wordList = fileToWords(file)  #convert file to list of words
		sortedWords = sortWords(wordList)  # convert word list to a sorted word list and no repeats
		countWords = countedWords(sortedWords,wordList)  # counts the amount of each word occurs
		lenWords = len(wordList)
		ratioWords = ratioFun(wordList,sortedWords,countWords)  # find ratio with 3dp
		outFunc(ratioWords,countWords,sortedWords)  # output function